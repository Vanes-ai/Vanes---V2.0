<?php
// Basic authentication placeholder
?>